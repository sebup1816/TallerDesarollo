# BackTwitterExample
This project is an example of the use of nodejs, expressjs, sequalize and mysql for making a back-end for an app similar to Twitter.
In the sourcecode there are some comments with proposed tasks for practice
